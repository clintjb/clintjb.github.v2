---
title: 'Super!'
date: 2014-02-27
description: Characters based on the styling and pose from the first appearance of Superman
tags: [stuff, pop culture, mike mitchell, portraits, superman]
categories: stuff
comments: true
featured_image: '/images/posts/2014/super-feature.jpg'
---

For those that don't know me so well, I'm a huge comics fan. This is a series entitled "Super" created by a very talented artist named [Mike Mitchell](http://www.sirmikeofmitchell.com/index.php?/super/) - anyway it’s a series of pop culture characters based on the styling and pose from the first appearance of Superman.

Fantastic Stuff!

![](/images/posts/2014/super.gif)