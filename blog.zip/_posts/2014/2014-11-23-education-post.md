---
title: 'Education'
date: 2014-11-23
description: Quote from Albert Einstein
tags: [business, einstein, quote, education]
categories: business
comments: true
featured_image: '/images/posts/2014/einstein-feature.jpg'
---

![](/images/posts/2014/einstein.jpg)

> Education is not the learning of facts, but training the mind to think.
> [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein)