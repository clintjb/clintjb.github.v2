---
title: 'Vinyl'
date: 2014-01-01
description: Personal vinyl collection
tags: [stuff, vinyl, records, music]
categories: stuff
comments: true
featured_image: '/images/vinyl/vinyl.jpg'
---

![](/images/vinyl/vinyl.jpg) 

<div class="gallery" data-columns="3">
	<img src="/images/vinyl/dp - discovery.jpg">
	<img src="/images/vinyl/jz - gray.jpg">
	<img src="/images/vinyl/kanye - mbdtf.jpg">
	<img src="/images/vinyl/u2 - 18.jpg">
</div>