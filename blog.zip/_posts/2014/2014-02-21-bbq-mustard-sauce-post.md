---
title: 'Sweet Mustard BBQ Sauce'
date: 2014-02-21
description: Goes great with pork, chicken - well just about anything actually!
tags: [cooking, bbq, sauce, mustard]
categories: cooking
comments: true
featured_image: '/images/posts/2014/bbqsauce-feature.jpg'
---

![](/images/posts/2014/bbqsauce.jpg)

This is one of the recipes I worked on last year - I'm genuinely pretty proud of this recipe now - goes great with pork but any meats good - it holds pretty well in the fridge as well.

* 1/2 cup yellow mustard
* 1/3 cup light brown sugar
* 1/3 cup apple cider vinegar
* 1/8 cup water
* 1 tablespoons chilli powder (not hot)
* 1 teaspoon black pepper
* dash of cayenne (hot)
* 1 teaspoon soy sauce
* 1 tablespoons butter
* 2 teaspoon liquid smoke (hickory flavouring)

Mix all except the soy, butter and liquid smoke. Simmer for 5-10 minutes. Stir in remaining ingredients and simmer for 5 more.

And that's it - absolute magic with pulled pork and will really give your next BBQ round something special. Make sure you give some feedback if you end up trying it out.

Cheers