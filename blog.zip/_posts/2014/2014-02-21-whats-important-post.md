---
title: 'What's Truly Important'
date: 2014-02-21
description: Quote from Barack Obama
tags: [business, obama, quote, barack]
categories: business
comments: true
featured_image: '/images/posts/2014/obama-feature.jpg'
---

![](/images/posts/2014/obama.jpg)

> The elevation of appearance over substance, of celebrity over character, of short term gains over lasting achievement displays a poverty of ambition. It distracts you from what's truly important.
> [Barack Obama](https://en.wikipedia.org/wiki/Barack_Obama)