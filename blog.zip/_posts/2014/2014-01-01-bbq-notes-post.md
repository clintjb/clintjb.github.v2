---
title: 'BBQ Notes'
date: 2014-01-01
description: Personal notes on temps and times while BBQing
tags: [cooking, bbq]
categories: cooking
comments: true
featured_image: '/images/posts/2014/notebook-feature.jpg'
---

![](/images/posts/2014/notebook.jpg)

Just some of my personal notes on temps and times while BBQ'ing

#### Ribs
* @ 100 Degrees
* 2 Hours Unwrapped
* 1 Hour Wrapped
* 30 Mins Unwrapped

*Perhaps Just The First 3 Hours Depending On Rib Thickness*

#### Pulled Pork
* Inject & Apply light mustard coat and rub the evening before (wrap in plastic)
* @ 110 - 115 Degrees
* Mop every 45mins or so
* Wrap once internal temp of 70 Degrees is achieved
* Unwrap once it hits 92 degrees and keep juices as finishing sauce
* 30 Mins Unwrapped

*Next Time Plan For 12 Hours With 2.7kgs*

#### Brisket

#### Chicken Wings
* @ 110 Degrees
* 2 Hours

#### Chicken Legs
* @ 110 Degrees
* 3 Hours

#### Tri Tip
* @ 100 Degrees
* Internal temp 50-55 degrees
* 1 - 1.5 Hours