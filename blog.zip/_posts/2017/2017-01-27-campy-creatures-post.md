---
title: 'Campy Creatures'
date: 2017-01-27
description: B-grade film inspired monster illustrations
tags: [stuff, pop culture, monsters, film, classic]
categories: stuff
comments: true
featured_image: '/images/posts/2017/creatures-feature.jpg'
---

![](/images/posts/2017/creatures-1.jpg)

I've been keeping an eye on these for a while. Basically [Josh Emrich](https://dribbble.com/emrichoffice) was commissioned to illustrate some characters for a new game called "Campy Creatures". I was never a great lover of tactical card games - but the 60s inspired artwork for this one is just too good not to share.

<div class="gallery" data-columns="3">
	<img src="/images/posts/2017/creatures-2.jpg">
	<img src="/images/posts/2017/creatures-3.jpg">
	<img src="/images/posts/2017/creatures-4.jpg">
	<img src="/images/posts/2017/creatures-5.jpg">
	<img src="/images/posts/2017/creatures-6.jpg">
	<img src="/images/posts/2017/creatures-7.jpg">
	<img src="/images/posts/2017/creatures-8.jpg">
	<img src="/images/posts/2017/creatures-9.jpg">
</div>
