---
title: 'Popscene'
date: 2017-10-20
description: A cool little scene will all kinds of randomness
tags: [stuff, pop culture, illustration, anime, mashup]
categories: stuff
comments: true
featured_image: '/images/posts/2017/popscene-feature.jpg'
---
Don't know where I found this one, but its certainly fun to look over and spot all the little happenings and whatnot.

![](/images/posts/2017/popscene.jpg)