---
title: 'Bacon!'
date: 2017-10-20
description: Bacon, Bacon, Bacon...
tags: [stuff, pop culture, illustration, bacon]
categories: stuff
comments: true
featured_image: '/images/posts/2017/bacon-feature.jpg'
---
Love it!

![](/images/posts/2017/bacon.jpg)