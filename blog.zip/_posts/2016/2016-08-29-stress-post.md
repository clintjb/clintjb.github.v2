---
title: 'Stress Or Passion'
date: 2016-08-29
description: Quote from Simon Sinek.
tags: [business, sinek, quote, stress, passion]
categories: business
comments: true
featured_image: '/images/posts/2016/sinek-feature.jpg'
---

![](/images/posts/2016/sinek.jpg)

> Working hard for something we don't care about is called stress; working hard for something we love is called passion.
> [Simon Sinek](https://en.wikipedia.org/wiki/Simon_Sinek)