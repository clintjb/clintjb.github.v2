---
title: 'Green Lights'
date: 2016-05-10
description: One of my few pet-peeves here in Germany.
tags: [pop culture, stuff, germany, joke]
categories: stuff
comments: true
featured_image: '/images/posts/2016/germany-feature.jpg'
---

![](/images/posts/2016/germany.jpg)

This was sent to me by my wife, as she laughs when I complain about this everytime I drive!