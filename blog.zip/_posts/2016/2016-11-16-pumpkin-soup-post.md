---
title: 'Pumpkin Soup'
date: 2016-11-16
description: Sprinkle with crunchy croutons and a touch of pumpkin seed oil.
tags: [cooking, soup, home made, pumpkin, curry, recipe]
categories: cooking
comments: true
featured_image: '/images/posts/2016/pumpkin-soup-feature.jpg'
---

![](/images/posts/2016/pumpkin-soup.jpg)

This is one of mums old recipes - Its something you can knock out super quick and for me goes brilliantly as an appetiser or main.

* 750g pumpkin
* 2 medium potatoes
* 1 onion
* 1 garlic clove
* 1 teaspoon mixed herbs
* 1 1/2 teaspoons curry powder
* 2 1/2 cups vegetable stock
* 1 cup cream

Dice the vegetables up into chunks, and add to a large pot with the vegetable stock and curry powder. Bring it to a simmer and continue to cook until the vegetables are tender.

Take the pot off the heat and allow it to cool. Once cooled, blend the vegetables until the soup is smooth.

Stir throughh the cream and season to taste.