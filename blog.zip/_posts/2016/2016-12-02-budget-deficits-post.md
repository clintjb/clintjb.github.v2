---
title: 'Budgets'
date: 2016-12-02
description: Budget deficits simplified.
tags: [business, budget, credit, crisis, financial, government, simple, deficit, explanation]
categories: business
comments: true
featured_image: '/images/posts/2016/budget-feature.jpg'
---

![](/images/posts/2016/budget.jpg)

Of course the topics significantly more complicated than this. Nevertheless, it breaks the complexity down to something that's exceptionally relatable and is one of the best examples of the KISS principles I've seen. 

I've been enjoying these financial simplifications as of late so feel free to find another great one [here](/credit-crisis-post).