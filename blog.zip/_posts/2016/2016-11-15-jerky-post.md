---
title: 'Jerky'
date: 2016-11-15
description: What's better to go with football and beer?
tags: [cooking, jerky, home made, beer, recipe]
categories: cooking
comments: true
featured_image: '/images/posts/2016/jerkey-feature.jpg'
---

![](/images/posts/2016/jerkey.jpg)

This is my own personal recipe that's a bit of a mix between a traditional jerky and South African Biltong. I've seen people do this on smokers as well as traditional hanging - I use a dehydrator but I'm certain the recipe would be great with whatever method you use. If you end up trying it with a different method I would love to hear about it so make sure you drop me a line.

* 500g beef
* 1 small chilli
* 1/2 tablespoon mixed herbs
* 1 tablespoon salt
* 1 tablespoon pepper
* 2 tablespoon brown sugar
* 1 1/2 tablespoons coriander
* 1/2 tablespoon dried garlic
* 1/2 tablespoon bicarb soda
* 1 tablespoon BBQ sauce
* 1 tablespoon honey
* 1/2 tablespoon vegemite
* 2 teaspoons liquid smoke
* 75ml balsamic vinegar
* 50ml port
* 50ml soja sauce

Freeze the beef until it just begins to stiffen (this allows you to slice it easier) Slice the beef with the grain in 1cm thick x 3cm wide full length strips.

Place all of the beef in the marinade and allow it to soak for the next 12 hours.

Layer the strips into the dehydrator and leave for ca 10 hours.