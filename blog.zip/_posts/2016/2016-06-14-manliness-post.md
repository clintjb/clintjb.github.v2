---
title: 'Life Rules For Being A Man'
date: 2016-06-14
description: A list of rules for boys of all ages.
tags: [stuff, life rules, man, manliness, wisdom]
categories: stuff
comments: true
featured_image: '/images/posts/2016/manliness-feature.jpg'
---

![](/images/posts/2016/manliness.jpg)

First things first, even from the title its clear some of these are a little chauvinistic - so apologies in advanced.

Years ago I come across a huge list of "manly" life rules that everyone should pass on to their sons (sorry I forgot the exact source of the list). So I made note of the ones I found particularly true and dumped them into my archive. After doing some spring cleaning last week I just come across them and decided to dump them here as food for thought. 

* When you give your word, keep it.
* Never take her to the movies on the first date.
* Always look a person in the eye when you talk to them.
* Never leave a beer unfinished.
* If you aren't confident, fake it. It will come around.
* You can tell the size of a man by the size of things that bother him.
* Always stand to shake someone's hand and give a firm handshake.
* Go for women out of your league. You may end up surprised.
* Manliness is not only being able to take care of yourself, but others as well.
* Go with the decision that will make for a good story.
* Nice guys don't finish last, boring guys do.
* Don't let the little head do the thinking for the big head.
* No matter who they are, everyone deserves respect. Or simply put "treat others the way you would like to be treated"
* The most important thing you can learn is personal responsibility.
* Bad things happen; it's your job to overcome them.
* You do what needs to be done without complaining.
* Never stop learning.
* Don't change yourself just to make someone happy.
* If you're the smartest person in the room, you're in the wrong room.
* Luck favours the prepared.
* Women find confidence sexy as hell.
* No one is on their deathbed wishing they spent more time at work

Seeing as I have a daughter as well, I should follow up and make a modified version of this list for some life lessons particularly suited to her. Having been a "less than perfect" teenage boy, I think I have some insights to explain why we act the way we do at times.

Cheers