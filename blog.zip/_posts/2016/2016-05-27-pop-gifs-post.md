---
title: 'Pop Gifs'
date: 2016-05-27
description: Some fun pixelated animated gifs.
tags: [pop culture, stuff, cars, vehicles]
categories: stuff
comments: true
featured_image: '/images/posts/2016/animation-feature.jpg'
---

![](/images/posts/2016/animation.jpg)

Here's some cool little animations based on some videogame and films - it was originally created by Alex Griendling [here](https://dribbble.com/alexgriendling).

<div class="gallery" data-columns="3">
	<img src="/images/posts/2016/animation-1.gif">
	<img src="/images/posts/2016/animation-2.gif">
	<img src="/images/posts/2016/animation-3.gif">
	<img src="/images/posts/2016/animation-4.gif">
	<img src="/images/posts/2016/animation-5.gif">
	<img src="/images/posts/2016/animation-6.gif">
	<img src="/images/posts/2016/animation-7.gif">
	<img src="/images/posts/2016/animation-8.gif">
	<img src="/images/posts/2016/animation-9.gif">
	<img src="/images/posts/2016/animation-10.gif">
	<img src="/images/posts/2016/animation-11.gif">
	<img src="/images/posts/2016/animation-12.gif">
</div>