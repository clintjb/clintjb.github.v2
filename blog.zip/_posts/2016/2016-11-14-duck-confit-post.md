---
title: 'Duck Confit'
date: 2016-11-14
description: 'Confit de canard' my French favourite.
tags: [cooking, duck, canard, confit, French, recipe, orange]
categories: cooking
comments: true
featured_image: '/images/posts/2016/confit-feature.jpg'
---

My confit recipe I end up cooking every November so its cured and ready just in time for those cold months.

* 4 duck legs
* 2 bay leaves crushed
* 4 carlic cloves crushed
* 2 teaspoons thyme
* 2 tablespoons salt
* Crushed pepper

Dry the duck and then prick the skin all over (this helps to make it go crispy) Sprinkle 1 Tablespoon of the salt on the base of the dish and lay the duck skin side down. Coat the remaining ingredients over the meat side of the legs and leave to cure overnight.

Remove Excess fat and render in pan.

Wash the duck legs and remove any excess seasoning and pat dry. Remove any excess fat and render it in a pan. Place the legs in pot (as minimal overlapping as possible) and cover with the duck fat and add olive oil to make up the difference.

Cook at 110 degrees for 3 - 4 hours until duck begins to fall off the bone. Remove the duck from the bone and add it to an airtight jar, covering with the fat.