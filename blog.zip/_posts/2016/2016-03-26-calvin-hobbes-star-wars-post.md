---
title: 'Calvin & Hobbes Inspired Star Wars'
date: 2016-03-26
description: Let's go exploring in a galaxy far, far away.
tags: [stuff, pop culture, calvin and hobbes, cartoons, mashup, star wars]
categories: stuff
comments: true
featured_image: '/images/posts/2016/starwars-feature.jpg'
---

Brian Kesinger, a story artist for Marvel and Disney Animation Studios, is a fan of both the Saturday morning comic and the famous sci-fi franchise, so he found an incredibly cute way to pay homage to both after seeing Star Wars: The Force Awakens. 

You can find Brian over here on his [Instagram](https://www.instagram.com/briankesinger/) account.

<div class="gallery" data-columns="3">
	<img src="/images/posts/2016/starwars-1.jpg">
	<img src="/images/posts/2016/starwars-2.jpg">
	<img src="/images/posts/2016/starwars-3.jpg">
	<img src="/images/posts/2016/starwars-4.jpg">
	<img src="/images/posts/2016/starwars-5.jpg">
	<img src="/images/posts/2016/starwars-6.jpg">
	<img src="/images/posts/2016/starwars-7.jpg">
	<img src="/images/posts/2016/starwars-8.jpg">
	<img src="/images/posts/2016/starwars-9.jpg">
</div>
