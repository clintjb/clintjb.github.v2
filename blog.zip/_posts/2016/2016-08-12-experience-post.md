---
title: 'Experience'
date: 2016-08-12
description: Quote from Vernon Law.
tags: [business, vernon, quote, experience]
categories: business
comments: true
featured_image: '/images/posts/2016/vernon-feature.jpg'
---

![](/images/posts/2016/vernon.jpg)

> Experience is a hard teacher because she gives the test first, the lesson afterwards.
> [Vernon Law](https://en.wikipedia.org/wiki/Vern_Law)