---
title: 'Scarcity'
date: 2016-04-19
description: Life lesson from Rufus Griscom.
tags: [stuff, pop culture, quote, life lessons]
categories: stuff
comments: true
featured_image: '/images/posts/2016/scarcity-feature.jpg'
---

![](/images/posts/2016/scarcity.jpg)

This was somehing quite simple that really spoke to me from a list of life lessons from [Rufus Griscom](observer.com/2016/04/unsolicited-advice-for-my-three-sons-in-no-particular-order/)

> If peanut butter could only be found in the placenta of a rare tropical bird, it would cost $1,000 per ounce. Sure, caviar tastes good, but so does peanut butter. People are irrationally attracted to that which is scarce, because scarce things function as status symbols. If you understand the elements of human behaviour that are irrational and predictable, you are freed from them and can benefit from the insight.