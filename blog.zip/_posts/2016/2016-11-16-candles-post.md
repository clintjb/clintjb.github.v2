---
title: 'The Lightbulb'
date: 2016-11-16
description: Quote from Oren Harari.
tags: [business, candle, quote, innovation, light, bulb, continuous improvement]
categories: business
comments: true
featured_image: '/images/posts/2016/harari-feature.jpg'
---

![](/images/posts/2016/harari.jpg)

> The electric light did not come from the continuous improvement of candles.
> [Oren Harari](https://en.wikipedia.org/wiki/Oren_Harari)