---
title: 'Audrey Hepburn'
date: 2016-07-12
description: A few little illustrations & paintings.
tags: [pop culture, stuff, illustrations, audrey, hepburn]
categories: stuff
comments: true
featured_image: '/images/posts/2016/audrey-feature.jpg'
---

![](/images/posts/2016/audrey.jpg)

She was spontaneous right from her first major role in "Roman Holiday," played sly comedy in "Sabrina" and showed a range of feeling in "Breakfast at Tiffany's." There's something incredibly charming about the lady that's impossible to put your finger on.

I really quite like all these illustrations and find they capture her and that spark quite well.

Cheers,

<div class="gallery" data-columns="3">
	<img src="/images/posts/2016/audrey-1.jpg">
	<img src="/images/posts/2016/audrey-2.jpg">
	<img src="/images/posts/2016/audrey-3.jpg">
	<img src="/images/posts/2016/audrey-4.jpg">
	<img src="/images/posts/2016/audrey-5.jpg">
	<img src="/images/posts/2016/audrey-6.jpg">
	<img src="/images/posts/2016/audrey-7.jpg">
	<img src="/images/posts/2016/audrey-8.jpg">
</div>