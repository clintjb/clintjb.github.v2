---
title: 'Without Data'
date: 2018-03-09
description: Quote from Edward Deming.
tags: [business, digitalization, deming, quote, data, science, edward, opinion, continuous improvement]
categories: digitalization
comments: true
featured_image: '/images/posts/2018/deming-feature.jpg'
---

![](/images/posts/2018/deming.jpg)

> Without data you're just another person with an opinion.
> [Edward Deming](https://en.wikipedia.org/wiki/W._Edwards_Deming)