---
title: 'Pork Injection'
date: 2015-10-13
description: Perfect injection to keep your cuts juicy during smoking
tags: [cooking, bbq, injection, pork, smoking]
categories: cooking
comments: true
featured_image: '/images/posts/2015/injection-feature.jpg'
---

![](/images/posts/2015/injection.jpg)

So a super simple injection that I use on my pulled pork - cant go wrong with this one.

* 1/2 cup apple juice
* 1/4 cup water
* 1/4 cup brown sugar
* 1/8 cup salt
* 1 tablespoons Worcestershire sauce

Mix all of them and bring it to a boil until everything's dissolved.

Let it sit in the fridge until its cooled off before injecting.