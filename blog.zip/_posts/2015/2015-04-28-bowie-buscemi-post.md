---
title: 'Bowie + Buscemi'
date: 2015-04-28
description: A mash-up of Steve Buscemi and David Bowies many varied personas
tags: [stuff, pop culture, david bowie, steve buscemi, mashup, portrait]
categories: stuff
comments: true
featured_image: '/images/posts/2015/buscemi-feature.jpg'
---

So anyway this was originally some work done from an illustrator named [Helen Green](http://dollychops.tumblr.com/).

In honour of Bowie's birthday she put together a series of illustrations from all his persona's over the years - well someone decided to "one-up" it by adding Steve Buscemi to the mix. 

I've got to admit, seeing as I'm a fan of both of them I really quite enjoyed the randomness of this. 

Cheers

![](/images/posts/2015/buscemi.gif)