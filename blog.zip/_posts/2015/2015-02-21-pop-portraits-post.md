---
title: 'Pop Portraits'
date: 2015-02-21
description: Side facing portraits based on all kinds of film characters
tags: [stuff, pop culture, mike mitchell, portraits]
categories: stuff
comments: true
featured_image: '/images/posts/2015/portraits-feature.jpg'
---

![](/images/posts/2015/portraits.jpg)

So here we are with another set of fantastic images from Mike Mitchell. 

You can find his Super! series I previously posted [here](http://www.clintbird.com/super-post/).

These are basically just a set of side facing portraits based on all kinds of film characters - Again fantastic work from Mike.

<div class="gallery" data-columns="3">
	<img src="/images/posts/2015/portraits-ash.jpg">
	<img src="/images/posts/2015/portraits-oldboy.jpg">
	<img src="/images/posts/2015/portraits-lloyd.jpg">
	<img src="/images/posts/2015/portraits-bride.jpg">
	<img src="/images/posts/2015/portraits-bunny.jpg">
	<img src="/images/posts/2015/portraits-doc.jpg">
	<img src="/images/posts/2015/portraits-hi.jpg">
	<img src="/images/posts/2015/portraits-dorothy.jpg">
	<img src="/images/posts/2015/portraits-igor.jpg">
	<img src="/images/posts/2015/portraits-beetlejuice.jpg">
	<img src="/images/posts/2015/portraits-macready.jpg">
	<img src="/images/posts/2015/portraits-jimmie.jpg">
	<img src="/images/posts/2015/portraits-joker.jpg">
	<img src="/images/posts/2015/portraits-mrpink.jpg">
	<img src="/images/posts/2015/portraits-mugatu.jpg">
	<img src="/images/posts/2015/portraits-nada.jpg">
	<img src="/images/posts/2015/portraits-naviny.jpg">
	<img src="/images/posts/2015/portraits-thegood.jpg">
</div>