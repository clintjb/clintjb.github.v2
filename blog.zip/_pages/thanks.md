---
title: Thanks!
subtitle: Your message was sent successfully.
description: 30 something year old digital / lean enthusiast and aspiring chef. 15+ years experience in operations, digitalization, cost reduction and project management.
featured_image: /images/headers/header-thanks.jpg
---

![](/images/headers/header-thanks.jpg)

Leo says you're awesome!
I appreciate you taking the time to contact me - I will get back to you shortly.
Thanks.