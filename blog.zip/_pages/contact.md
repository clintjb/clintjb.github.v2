---
title: Contact
subtitle: If you would like to connect with me, share a story or just have a chat about anything, then feel free to have a look around and get in touch.
description: 30 something year old digital / lean enthusiast and aspiring chef. 15+ years experience in operations, digitalization, cost reduction and project management.
featured_image: /images/headers/header-contact.jpg
---

{% include contact-form.html %}